setwd("C:\\Users\\it24103365\\Desktop\\IT24103365")
getwd()

# 1. Import the dataset (‘Exercise – Lab 05.txt’) into R and store it in a data frame called “Delivery Times”
Delivery_Times <- read.table("Exercise - Lab 05.txt", header=TRUE, col.names="Delivery_Time_minutes")
times <- Delivery_Times$Delivery_Time_minutes

# 2. Draw a histogram for deliver times using nine class intervals where the lower limit is 20 and upper limit is 70. Use right open intervals.
breaks_nine <- seq(20, 70, length.out=10)
hist(times, breaks=breaks_nine, main="Histogram of Delivery Times (9 Classes, 20-70)", xlab="Delivery Time (minutes)", ylab="Frequency", right=FALSE)


                
# 3. Comment on the shape of the distribution.
# The distribution appears slightly right-skewed with most delivery times clustered between 30 and 60 minutes.

# 4. Draw a cumulative frequency polygon (ogive) for the data in a separate plot.
h_ex <- hist(times, breaks=breaks_nine, plot=FALSE)
cum_freq_ex <- c(0, cumsum(h_ex$counts))
plot(breaks_nine, cum_freq_ex, type="b", main="Cumulative Frequency Polygon (Ogive) for Delivery Times", xlab="Delivery Time (minutes)", ylab="Cumulative Frequency", pch=19)