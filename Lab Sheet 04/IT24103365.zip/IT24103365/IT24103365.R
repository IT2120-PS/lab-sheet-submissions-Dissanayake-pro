setwd("C:\\Users\\it24103365\\Desktop\\IT24103365")

# PART B 
# 1.
branch_data <- read.csv("Exercise.txt", header=TRUE)
head(branch_data)
str(branch_data)

# 2.
# Branch - Identifier (Nominal)
# Sales_X1 - Ratio
# Advertising_X2 - Ratio
# Years_X3 - Ratio


# 3.
boxplot(branch_data$Sales_X1, main="Boxplot of Sales", ylab="Sales")


# 4.
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

# 5.
find_outliers(branch_data$Years_X3)

